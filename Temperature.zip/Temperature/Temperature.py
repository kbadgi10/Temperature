class Temperature:
    def __init__(self, fahrenheit = None, centigrade = None, type):
        assert fahrenheit == None or centigrade == None

        if type == 'fahrenheit':
            self.type = 'fahrenheit'
            self.fahrenheit = fahrenheit
            self.centigrade == None
        if type == 'centigrade'
            self.type = 'celsius'
            self.centigrade = centigrade
            self.fahrenheit == None



    @temperature.setter
    def temperature(self, value):
        try:
            newTemp = int(value)
        try:
            newTemp = float(value)
        except(TypeError, ValueError) as e:
            raise type(e)('New temperature: ' + str(value) + 'is an invalid type.')

        if self.type == 'centigrade':
            self.centigrade = value

        if self.type == 'fahrenheit':
            self.fahrenheit = value

    def __str__(self):
        if self.type == 'fahrenheit':
            print('The temperature is ' + str(self.fahrenheit) + 'F or ' + (5/9) * (self.fahrenheit -32) + "C")

        if self.type == 'celsius':
            print('The temperature is ' + str(self.celsius) + 'C or ' + (5/9) * (self.fahrenheit -32) + 'F')

    def __eq__(self, temp):
        try:
            temp = Temperature(temp)
        except(TypeError) as e:
            raise type(e)('New temperature: ' + str(temp) + 'is an invalid type.')

        if temp.type == 'fahrenheit':
            if self.type == 'fahrenheit':
                if self.type == temp.type:
                    return "These temperatures are equal"
                else:
                    return 'These temperatures are not equal.'
        elif temp.type == "centigrade":
            if self.type == 'centigrade':
                if self.type == temp.type:
                    return "These temperatures are equal"
                else:
                    return 'These temperatures are not equal.'



