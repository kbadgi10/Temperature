import Temperature
from Temperature import *

t1 = Temperature(100, 'fahrenheit')
t2 = Temperature(37.7, 'centigrade')

print(t1)
print(t2)

print(t1 == t2)

